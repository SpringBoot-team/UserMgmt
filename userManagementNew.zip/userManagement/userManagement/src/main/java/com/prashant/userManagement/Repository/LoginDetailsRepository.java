package com.prashant.userManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.prashant.userManagement.Entity.LoginDataEntity;

public interface LoginDetailsRepository  extends JpaRepository<LoginDataEntity, String> {
 
	 @Query(value="SELECT password FROM login_details s where s.username = ?1  ",nativeQuery=true)
	 String findPassword(String username);
	 
	 @Query(value="SELECT username FROM login_details s where s.username = ?1  ",nativeQuery=true)
	 String findUsername(String username);
	
}
