package com.prashant.userManagement.Service;

import com.prashant.userManagement.RequestModel.UserDetails;

public interface UserMgmtServiceInt {
	public UserDetails getAllDetails(UserDetails details);
}
