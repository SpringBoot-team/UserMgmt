package com.prashant.userManagement.RequestModel;

public class UserDetails {


	String name;
	
	String address;
	
	String Age;
	
	String gender;
	
	String Mob_no;
	
	String Email;
	
	String username;
	
	String password;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMob_no() {
		return Mob_no;
	}
	public void setMob_no(String mob_no) {
		Mob_no = mob_no;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserDetails [name=" + name + ", address=" + address + ", Age=" + Age + ",Gender="+gender+", Username="+username+", Mob_no="+Mob_no+",Email="+Email+"]";
	}
	
	
}

