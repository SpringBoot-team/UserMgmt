package com.prashant.userManagement.Service;

import com.prashant.userManagement.RequestModel.ForgotPassword;

public interface OtpServiceInt {
	public String sendOTP(ForgotPassword details);
}
