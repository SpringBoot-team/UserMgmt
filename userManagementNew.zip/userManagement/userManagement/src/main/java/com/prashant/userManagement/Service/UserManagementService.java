package com.prashant.userManagement.Service;

import java.security.SecureRandom;

import org.springframework.stereotype.Service;

import com.prashant.userManagement.RequestModel.UserDetails;

@Service
public class UserManagementService implements UserMgmtServiceInt {
String pwd;
	public UserDetails getAllDetails(UserDetails details){
		System.out.println("Inside service and Details are==>> "+details);
		System.out.println(details.getAddress());
		//details.setName("Prashant Rawat");
		//details.setAddress("Jagner,Agra");
		//details.setAge("22");
		if(details!=null)
			pwd=generateRandomPassword(10);
		details.setPassword(pwd);
		return details;
	}
	 public static String generateRandomPassword(int len)
		{
			// ASCII range - alphanumeric (0-9, a-z, A-Z)
			final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

			SecureRandom random = new SecureRandom();
			StringBuilder sb = new StringBuilder();

			// each iteration of loop choose a character randomly from the given ASCII range
			// and append it to StringBuilder instance

			for (int i = 0; i < len; i++) {
				int randomIndex = random.nextInt(chars.length());
				sb.append(chars.charAt(randomIndex));
			}

			return sb.toString();
		}
	
}
