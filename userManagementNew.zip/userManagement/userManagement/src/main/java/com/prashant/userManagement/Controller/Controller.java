package com.prashant.userManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prashant.userManagement.Entity.LoginDataEntity;
import com.prashant.userManagement.Entity.UserDetailsDb;
import com.prashant.userManagement.Repository.LoginDetailsRepository;
import com.prashant.userManagement.Repository.UserDetailsRepository;
import com.prashant.userManagement.RequestModel.*;
import com.prashant.userManagement.Service.*;

@RestController
@RequestMapping("/user")


public class Controller {
	String name;
	String pwd;
	String mob;
	String email;
	 @Autowired
	    UserManagementService service;
	 @Autowired
	 EmailService e_service;
	 @Autowired
	 UserDetailsRepository userrepository;
	@Autowired
	LoginDetailsRepository loginrepo;

	@PostMapping("/signUp")
	
//	 public @ResponseBody String addNewUser (@RequestParam String name
//		      , @RequestParam String address, @RequestParam String age) {
//		    // @ResponseBody means the returned String is the response, not a view name
//		    // @RequestParam means it is a parameter from the GET or POST request
//
//		    UserDetailsDb n = new UserDetailsDb();
//		    n.setName(name);
//		    n.setAge(age);
//		    n.setAddress(address);
//		    userrepository.save(n);
//		    return "Saved";
//		  }
		public UserDetails signUp(@RequestBody UserDetails details,LoginDetails ld) {
		
		
		System.out.println("UserDetails : "+details.toString());
		System.out.println("Login Details: "+ld.toString());
		details=service.getAllDetails(details);
		System.out.println(e_service.sendMail(details));
		System.out.println("Data after Return from Service==>>> "+ details.getAddress());
		
		 // @ResponseBody means the returned String is the response, not a view name
	    // @RequestParam means it is a parameter from the GET or POST request
//		if(details!=null)
//			 pwd=generateRandomPassword(10);
		this.name=details.getName();
		UserDetailsDb userdet=new UserDetailsDb();
		System.out.println("datils values:"+details);
		userdet.setName(details.getName());
		userdet.setAge(details.getAge());	
		userdet.setAddress(details.getAddress());
		userdet.setEmail(details.getEmail());
		userdet.setGender(details.getGender());
		userdet.setMob_no(details.getMob_no());
		userdet.setUsername(details.getUsername());
		 LoginDataEntity lde=new LoginDataEntity();
			lde.setUsername(details.getUsername());
			lde.setPassword(details.getPassword());
		 userrepository.save(userdet);
		loginrepo.save(lde);
	    return details;
		
		
	}
	
	 @GetMapping(path="/all")
	  public @ResponseBody Iterable<UserDetailsDb> getAllUsers() {
	    // This returns a JSON or XML with the users
//	    return userrepository.findAll();
		 return userrepository.findAllDetails("Prashant Rawat");
	  }
	 
	 @GetMapping(path="/allUsers")
	  public @ResponseBody Iterable<UserDetailsDb> getUsers() {
	    // This returns a JSON or XML with the users
	    return userrepository.findAll();
	  }
	 
	 @GetMapping("/showCitiesEnding")
	    public List<UserDetailsDb> findCitiesNameEndsWith(Model model) {

	        List<UserDetailsDb> alldetails = (List<UserDetailsDb>) userrepository.findAllDetails(this.name);

	        
System.out.println(alldetails);
	        return alldetails;
	    }
	
	@PostMapping("/login")
	public String login(@RequestBody LoginDetails details) {
		//String to_mail=this.findEmail(details);
		//System.out.println("Userdetails are:===>>>"+this.findEmail(details));
		if(this.MatchLoginCredentials(details).equals(details.getPassword()) && this.findEmail(details).equals(details.getUsername()))
			return "Login Successful";

//	    System.out.println("Done");
//		System.out.println("LoginDetails :"+ details.toString());
		
		else
			return "Login Failed,Credentials Not Matched!!";
	}
	
	@PostMapping("/forgotPassword")
	public String forgotPassword(@RequestBody ForgotPassword details) {
		
//		System.out.println("Password :"+ details.toString());
		System.out.println(findMobile(details));
		email=find_Email(details);
		pwd=findPassword(details);
		return e_service.sendMail(email, pwd);
	}
	
	
	 String find_Email(ForgotPassword details) {
		 
		 return userrepository.findEmail(details.getUsername());
	 }
	 
	 String findEmail(LoginDetails details) {
		 
		 return loginrepo.findUsername(details.getUsername());
	 }
	 
	 String MatchLoginCredentials(LoginDetails details) {
		 return loginrepo.findPassword(details.getUsername());
	 }
	 
	 String findPassword(ForgotPassword details) {
		 return loginrepo.findPassword(details.getUsername());
	 }
	 
	 String findMobile(ForgotPassword details) {
		 return userrepository.findMobile(details.getUsername());
	 }
	 
	
}
