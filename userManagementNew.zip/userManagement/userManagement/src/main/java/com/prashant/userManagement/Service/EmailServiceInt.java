package com.prashant.userManagement.Service;

import com.prashant.userManagement.RequestModel.UserDetails;

public interface EmailServiceInt {
	public String sendMail(UserDetails details);
}
