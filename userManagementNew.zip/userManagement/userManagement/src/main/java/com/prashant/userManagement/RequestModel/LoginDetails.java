package com.prashant.userManagement.RequestModel;

public class LoginDetails {
	
	String id;
	
	 String username;
	
	 String Password;



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}
	
	@Override
	
	public String toString() {
		return "LoginDetails [username=" + username + ", Password=" + Password + "]";
	}
	

}
