package com.prashant.userManagement.Service;

import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.prashant.userManagement.RequestModel.ForgotPassword;
import com.prashant.userManagement.RequestModel.UserDetails;

@Service
public class EmailService implements EmailServiceInt {
	@Autowired
	private JavaMailSender javaMailSender;
	

	
	public String sendMail(UserDetails details) {
		// TODO Auto-generated method stub
		System.out.println(details);
		try{
			sendEmail(details);
		}catch(Exception e) {
			System.out.println(e);
		}
		
		return "Email Successfully sent!!!";
	}
	
	public String sendMail(String to_email,String pwd) {
		// TODO Auto-generated method stub
		System.out.println(to_email+"---"+pwd);
		try{
			sendForgotEmail(to_email,pwd);
		}catch(Exception e) {
			System.out.println(e);
			return "Password not due to some exception!!!";
		}
		
		return "Password Successfully sent to registered email!!!";
	}
	
	void sendEmail(UserDetails details) throws MessagingException {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(details.getEmail());
       // String message="You have Successfully registered and your password for the first time login is : "+details.getPassword();
        msg.setSubject("Login Successful");
        msg.setText("You have Successfully registered and your password for the first time login is :"+details.getPassword());
        
        javaMailSender.send(msg);
        
     

    }
	
	void sendForgotEmail(String to_email,String pwd) throws MessagingException {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(to_email);
       // String message="You have Successfully registered and your password for the first time login is : "+details.getPassword();
        msg.setSubject("Password for login");
        msg.setText("Dear user Your Password for login is :"+pwd);
        
        javaMailSender.send(msg);
        
     

    }

}
