package com.prashant.userManagement.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.prashant.userManagement.Entity.UserDetailsDb;

//This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
//CRUD refers Create, Read, Update, Delete
public interface UserDetailsRepository extends JpaRepository<UserDetailsDb, String> {
	 @Query(value = "SELECT * FROM user_Details s where s.name = ?1 ", nativeQuery = true)
	 
//	 UserDetailsDb findAllDetails(String name);
	 List<UserDetailsDb> findAllDetails(String name);
	 
	 @Query(value="SELECT email FROM user_Details s where s.username = ?1  ",nativeQuery=true)
	 String findEmail(String username);
	 
	 @Query(value="SELECT mob_no FROM user_Details s where s.username = ?1  ",nativeQuery=true)
	 String findMobile(String username);
	 
	
	
}
