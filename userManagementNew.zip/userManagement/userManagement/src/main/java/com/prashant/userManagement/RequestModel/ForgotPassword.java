package com.prashant.userManagement.RequestModel;

import org.springframework.beans.factory.annotation.Autowired;

public class ForgotPassword {

	String Username;
	
//	String Password;
	
	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

//	public String getPassword() {
//		return Password;
//	}

//	LoginDetails log=new LoginDetails();
//	@Autowired
//	//private LoginDetails logindetails;
//	public void setPassword(LoginDetails logindetails) {
//		System.out.println(logindetails);
//		Password = logindetails.Password;
//	}
	
	@Override
	
	public String toString() {
		System.out.println("inside toString method");
		System.out.println("outside toString method");
		return "UserDetails [username=" + Username + "]";
	}
	
	
	
}

